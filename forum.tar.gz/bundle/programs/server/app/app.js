var require = meteorInstall({"views":{"pages":{"blog.html":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// views/pages/blog.html                                                                //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //

      if (Meteor.isServer) return;

      var templateUrl = "/views/pages/blog.html";
      var template = "<section class=\"module bg-dark-60\" data-background=\"assets/images/blog_bg.jpg\"> <div class=\"container\"> <div class=\"row\"> <div class=\"col-sm-6 col-sm-offset-3\"> <h2 class=\"module-title font-alt\" style=\"margin-bottom:3px!important\">{{ blog.name }}</h2> <h4 class=\"align-center font-alt\">{{ blog.author }}</h4> </div> </div> </div> </section> <section class=\"module-small\"> <div class=\"container\"> <div class=\"row\"> <div class=\"col-sm-12\"> <div class=\"post\"> <div class=\"post-entry\"> <p ng-bind-html=\"trustHtml(blog.content)\"></p> </div> </div> <div class=\"comments\"> <h4 class=\"comment-title font-alt\">There are 3 comments</h4> <div class=\"comment clearfix\"> <div class=\"comment-avatar\"><img src=\"https://s3.amazonaws.com/uifaces/faces/twitter/ryanbattles/128.jpg\" alt=\"avatar\"></div> <div class=\"comment-content clearfix\"> <div class=\"comment-author font-alt\"><a href=\"#\">John Doe</a></div> <div class=\"comment-body\"> <p>The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The European languages are members of the same family. Their separate existence is a myth.</p> </div> <div class=\"comment-meta font-alt\">Today, 14:55 - <a href=\"#\">Reply</a> </div> </div> <div class=\"comment clearfix\"> <div class=\"comment-avatar\"><img src=\"https://s3.amazonaws.com/uifaces/faces/twitter/draganbabic/128.jpg\" alt=\"avatar\"></div> <div class=\"comment-content clearfix\"> <div class=\"comment-author font-alt\"><a href=\"#\">Mark Stone</a></div> <div class=\"comment-body\"> <p>Europe uses the same vocabulary. The European languages are members of the same family. Their separate existence is a myth.</p> </div> <div class=\"comment-meta font-alt\">Today, 15:34 - <a href=\"#\">Reply</a> </div> </div> </div> </div> <div class=\"comment clearfix\"> <div class=\"comment-avatar\"><img src=\"https://s3.amazonaws.com/uifaces/faces/twitter/pixeliris/128.jpg\" alt=\"avatar\"></div> <div class=\"comment-content clearfix\"> <div class=\"comment-author font-alt\"><a href=\"#\">Andy</a></div> <div class=\"comment-body\"> <p>The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The European languages are members of the same family. Their separate existence is a myth.</p> </div> <div class=\"comment-meta font-alt\">Today, 14:59 - <a href=\"#\">Reply</a> </div> </div> </div> </div> <div class=\"comment-form\"> <h4 class=\"comment-form-title font-alt\">Add your comment</h4> <form method=\"post\"> <div class=\"form-group\"> <label class=\"sr-only\" for=\"name\">Name</label> <input class=\"form-control\" id=\"name\" type=\"text\" name=\"name\" placeholder=\"Name\"> </div> <div class=\"form-group\"> <label class=\"sr-only\" for=\"email\">Name</label> <input class=\"form-control\" id=\"email\" type=\"text\" name=\"email\" placeholder=\"E-mail\"> </div> <div class=\"form-group\"> <textarea class=\"form-control\" id=\"comment\" name=\"comment\" rows=\"4\" placeholder=\"Comment\"></textarea> </div> <button class=\"btn btn-round btn-d\" type=\"submit\">Post comment</button> </form> </div> </div> </div> </div> </section> <section class=\"module\"> <div class=\"container\"> <div style=\"border-top:1px dotted #c2c2c2\"></div> <div class=\"col-sm-9 col-sm-offest-3\"> <h3>Want to write a blog post on your project?</h3> <p>Contact us at tinkererslab@iith.ac.in</p> </div> </div> </section> ";

      angular.module('angular-templates')
        .run(['$templateCache', function($templateCache) {
          $templateCache.put(templateUrl, template);
        }]);

      module.exports = {};
      module.exports.__esModule = true;
      module.exports.default = templateUrl;
    
//////////////////////////////////////////////////////////////////////////////////////////

},"blogs.html":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// views/pages/blogs.html                                                               //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //

      if (Meteor.isServer) return;

      var templateUrl = "/views/pages/blogs.html";
      var template = "<section class=\"module bg-dark-60 blog-page-header\" data-background=\"assets/images/blog_bg.jpg\"> <div class=\"container\"> <div class=\"row\"> <div class=\"col-sm-6 col-sm-offset-3\"> <h2 class=\"module-title font-alt\">Tinkerer's Lab Blog</h2> <div class=\"module-subtitle font-serif\">Chronicles of past TL projects</div> </div> </div> </div> </section> <section class=\"module\"> <div class=\"container\"> <div class=\"row multi-columns-row post-columns\"> <div class=\"col-sm-6 col-md-4 col-lg-4\" ng-repeat=\"blog in blogs\"> <div class=\"post\"> <div class=\"post-thumbnail\"><img src=\"assets/images/post-1.jpg\" alt=\"Blog-post Thumbnail\"></div> <div class=\"post-header font-alt\"> <h2 class=\"post-title\"><a ui-sref=\"blog({blogId: blog._id})\">{{ blog.name }}</a></h2> <div class=\"post-meta\">By&nbsp;{{ blog.author }}&nbsp;| 23 November | 3 Comments </div> </div> <div class=\"post-entry\"> <p>A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.</p> </div> <div class=\"post-more\"><a class=\"more-link\" ui-sref=\"blog({blogId: blog._id})\">Read more</a></div> </div> </div> </div> </div> </section> <section class=\"module\"> <div class=\"container\"> <div style=\"border-top:1px dotted #c2c2c2\"></div> <div class=\"col-sm-9 col-sm-offest-3\"> <h3>Want to write a blog post on your project?</h3> <p>Contact us at tinkererslab@iith.ac.in</p> </div> </div> </section> ";

      angular.module('angular-templates')
        .run(['$templateCache', function($templateCache) {
          $templateCache.put(templateUrl, template);
        }]);

      module.exports = {};
      module.exports.__esModule = true;
      module.exports.default = templateUrl;
    
//////////////////////////////////////////////////////////////////////////////////////////

},"thread.html":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// views/pages/thread.html                                                              //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //

      if (Meteor.isServer) return;

      var templateUrl = "/views/pages/thread.html";
      var template = "<section class=\"module\"> <div class=\"page\"> <div class=\"container\"> <link rel=\"stylesheet\" type=\"text/css\" href=\"assets/css/trix.css\"> <script src=\"//cdnjs.cloudflare.com/ajax/libs/trix/0.9.2/trix.js\"></script> <script src=\"dist/angular-trix.min.js\"></script> <p>{{ thread.title }}</p> <p>by {{ thread.author }} on {{ thread.createdAt | date}}</p> <p ng-bind-html=\"trustHtml(thread.content)\"></p> <ul> <li ng-repeat=\"post in posts\"> <p ng-bind=\"post.content\"></p> by {{ post.author }} at {{ post.createdAt | date }} </li> </ul> <h2>Reply</h2> <form ng-submit=\"createPost(post)\"> <input type=\"text\" placeholder=\"Write your reply...\" ng-model=\"post.content\"> <button type=\"submit\">Post</button> </form> </div> </div> </section>";

      angular.module('angular-templates')
        .run(['$templateCache', function($templateCache) {
          $templateCache.put(templateUrl, template);
        }]);

      module.exports = {};
      module.exports.__esModule = true;
      module.exports.default = templateUrl;
    
//////////////////////////////////////////////////////////////////////////////////////////

},"topic.html":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// views/pages/topic.html                                                               //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //

      if (Meteor.isServer) return;

      var templateUrl = "/views/pages/topic.html";
      var template = "<section class=\"module-medium\"> <div class=\"page\"> <div class=\"container\"> <link rel=\"stylesheet\" type=\"text/css\" href=\"assets/css/trix.css\"> <!-- <script src=\"//ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js\"></script> --> <script src=\"//cdnjs.cloudflare.com/ajax/libs/trix/0.9.2/trix.js\"></script> <script src=\"dist/angular-trix.min.js\"></script> <div class=\"row\"> <div class=\"col-sm-11\"> <h2 class=\"font-alt\">{{ topic.name }}</h2> </div> <div class=\"col-sm-1 et-icons\"> <!-- <span class=\"box1\" title=\"Create new thread\"><span class=\"icon-pencil\" aria-hidden=\"true\"></span></span> --> <button type=\"button\" class=\"btn btn-info btn-lg\" data-toggle=\"modal\" data-target=\"#myModal\">Create Thread</button> </div> </div> <div id=\"myModal\" class=\"modal fade\" role=\"dialog\"> <div class=\"modal-dialog\"> <!-- Modal content--> <div class=\"modal-content\" style=\"\"> <div class=\"modal-header\"> <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button> <h4 class=\"modal-title font-alt\">Create a new thread</h4> </div> <div class=\"modal-body\"> <form ng-submit=\"createThread(thread)\"> <input type=\"text\" placeholder=\" Thread title\" ng-model=\"thread.title\" class=\"mb-10\"> <trix-editor angular-trix ng-model=\"thread.content\" class=\"trix-content\"></trix-editor> <button type=\"submit\" class=\"btn btn-info btn-lg mt-10\">Create!</button> </form> </div> <div class=\"modal-footer\"> <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button> </div> </div> </div> </div> <h4 class=\"font-serif\">{{ topic.description }}</h4> <div class=\"row multi-columns-row pb-20\" ng-repeat=\"thread in threads\" style=\"border-bottom:1px solid #e5e5e5\"> <div class=\"col-sm-12\" style=\"border-top:1px solid #e5e5e5\"> <h3 class=\"font-alt align-left\"><a ui-sref=\"thread({ threadId: thread._id })\">{{ thread.title }}</a></h3> </div> <div class=\"col-sm-8\"> <div class=\"font-serif align-left\">{{ thread.author }}</div> </div> <div class=\"col-sm-4\"> <div class=\"font-serif align-right\">{{ thread.createdAt | date}}</div> </div> </div> <!-- <ul>\n\t\t\t\t\t<li ng-repeat=\"thread in threads\">\n\t\t\t\t\t\t<a ui-sref=\"thread({threadId: thread._id})\">{{ thread.title }}</a>\n\t\t\t\t\t\tby {{ thread.author }} at {{ thread.createdAt | date }}\n\t\t\t\t\t</li>\n\t\t\t\t</ul> --> </div> </div></section>";

      angular.module('angular-templates')
        .run(['$templateCache', function($templateCache) {
          $templateCache.put(templateUrl, template);
        }]);

      module.exports = {};
      module.exports.__esModule = true;
      module.exports.default = templateUrl;
    
//////////////////////////////////////////////////////////////////////////////////////////

},"topics.html":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// views/pages/topics.html                                                              //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //

      if (Meteor.isServer) return;

      var templateUrl = "/views/pages/topics.html";
      var template = " <section class=\"module\"> <div class=\"container\"> <div class=\"page\"> <h1 class=\"module-title font-alt\">Topics</h1> <div class=\"row\" ng-repeat=\"topic in topics\" ui-sref=\"topic({topicId: topic._id})\"> <div class=\"col-xs-12 col-md-12 topic-text\"> <div class=\"row\"> <div class=\"col-sm-12\"> <h3 class=\"module-title font-alt align-left\"><a ui-sref=\"topic({topicId: topic._id})\">{{ topic.name }}</a></h3> <div class=\"module-subtitle font-serif align-left\" style=\"margin-bottom:10px!important\">{{ topic.description }}</div> </div> </div> </div> </div> </div> </div> </section>";

      angular.module('angular-templates')
        .run(['$templateCache', function($templateCache) {
          $templateCache.put(templateUrl, template);
        }]);

      module.exports = {};
      module.exports.__esModule = true;
      module.exports.default = templateUrl;
    
//////////////////////////////////////////////////////////////////////////////////////////

},"welcome.html":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// views/pages/welcome.html                                                             //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //

      if (Meteor.isServer) return;

      var templateUrl = "/views/pages/welcome.html";
      var template = "<section class=\"home-section home-full-height photography-page\" id=\"home\"> <div class=\"hero-slider\"> <ul class=\"slides\"> <li class=\"bg-dark\" style=\"background-image:url(&quot;assets/images/photography/image6.jpg&quot;)\"> <div class=\"container\"> <div class=\"image-caption\"> <div class=\"font-alt caption-text\">Placeholder image</div> </div> </div> </li> <li class=\"bg-dark\" style=\"background-image:url(&quot;assets/images/photography/image1.jpg&quot;)\"> <div class=\"container\"> <div class=\"image-caption\"> <div class=\"font-alt caption-text\">Placeholder image</div> </div> </div> </li> <li class=\"bg-dark\" style=\"background-image:url(&quot;assets/images/photography/image2.jpg&quot;)\"> <div class=\"container\"> <div class=\"image-caption\"> <div class=\"font-alt caption-text\">Placeholder image</div> </div> </div> </li> <li class=\"bg-dark\" style=\"background-image:url(&quot;assets/images/photography/image3.jpg&quot;)\"> <div class=\"container\"> <div class=\"image-caption\"> <div class=\"font-alt caption-text\">Placeholder image</div> </div> </div> </li> <li class=\"bg-dark\" style=\"background-image:url(&quot;assets/images/photography/image4.jpg&quot;)\"> <div class=\"container\"> <div class=\"image-caption\"> <div class=\"font-alt caption-text\">Placeholder image</div> </div> </div> </li> <li class=\"bg-dark\" style=\"background-image:url(&quot;assets/images/photography/image5.jpg&quot;)\"> <div class=\"container\"> <div class=\"image-caption\"> <div class=\"font-alt caption-text\">Placeholder image</div> </div> </div> </li> </ul> </div> <div class=\"titan-caption\" style=\"position:absolute!important;z-index:30;top:0\"> <div class=\"caption-content\" style=\"color:#fff\"> <div class=\"font-alt mb-20 titan-title-size-3\">Tinkerer's Lab, IITH</div> <div class=\"font-alt mb-20 titan-title-size-1\">Tinkerer's Lab is IITH's 24/7 student-run lab which is awesome, lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed venenatis ac ipsum id efficitur. Phasellus.</div><a class=\"section-scroll btn btn-border-w btn-round\" href=\"#services\">Learn More</a> </div> </div> </section> <section class=\"module\" id=\"services\"> <div class=\"container\"> <div class=\"row\"> <div class=\"col-sm-8 col-sm-offset-2\"> <h2 class=\"module-title font-alt\">Our Aim</h2> <div class=\"module-subtitle font-serif\" style=\"margin-bottom:5px!important\">Innovation is the outcome of a habit, not a random act.</div> <div class=\"module-subtitle\">Here, at Tinkerer's Lab, our aim is to provide you with an open facility with a vast range of tools in order to bring out the inner tinkerer in you.</div> </div> </div> <div class=\"row multi-columns-row\"> <div class=\"col-md-3 col-sm-6 col-xs-12\"> <div class=\"features-item\"> <div class=\"features-icon\"><span class=\"icon-clock\"></span></div> <h3 class=\"features-title font-alt\">Always Available</h3> <p>We know that the best ideas don't always come to us during work hours. Tinkerer's Lab is open 24/7, giving you the liberty to build and innovate whenever.</p> </div> </div> <div class=\"col-md-3 col-sm-6 col-xs-12\"> <div class=\"features-item\"> <div class=\"features-icon\"><span class=\"icon-lightbulb\"></span></div> <h3 class=\"features-title font-alt\">Transparency of Ideas</h3> <p>Our Portal not only keeps a track of every single project in Tinkerer's Lab, it also has a section dedicated to sharing ideas, making collaboration and inspiration easy.</p> </div> </div> <div class=\"col-md-3 col-sm-6 col-xs-12\"> <div class=\"features-item\"> <div class=\"features-icon\"><span class=\"icon-tools-2\"></span></div> <h3 class=\"features-title font-alt\">Resources</h3> <p>We have a wide variety of resources, from the commonplace Raspberry Pis and drills to CNC Machines and 3D Printers. You can also request advice from any proffessor directly from our portal.</p> </div> </div> <div class=\"col-md-3 col-sm-6 col-xs-12\"> <div class=\"features-item\"> <div class=\"features-icon\"><span class=\"icon-chat\"></span></div> <h3 class=\"features-title font-alt\">TL Talks</h3> <p>From time to time, TL will host talks and sessions by innovators and entrepreneurs to help develop interest in new fields and push boundaries.</p> </div> </div> </div> </div> </section> <section class=\"module\" id=\"news\"> <div class=\"container\"> <div class=\"row\"> <div class=\"col-sm-6 col-sm-offset-3\"> <h2 class=\"module-title font-alt\">Latest Blog Posts</h2> <div class=\"module-subtitle\">Here's a collection of blog posts that document the most recent projects finished at Tinkerer's Lab.</div> </div> </div> <div class=\"row multi-columns-row post-columns\"> <div class=\"col-sm-6 col-md-4 col-lg-4\"> <div class=\"post mb-20\"> <div class=\"post-thumbnail\"><a href=\"#\"><img src=\"assets/images/work-1.jpg\" alt=\"Blog-post Thumbnail\"></a></div> <div class=\"post-header font-alt\"> <h2 class=\"post-title\"><a href=\"#\">As Cool As Keyboards Can Get</a></h2> <div class=\"post-meta\">By&nbsp;<a href=\"#\">Tom</a>&nbsp;| 23 November | 3 Comments </div> </div> <div class=\"post-entry\"> <p>I recently decided to get myself a mechanical keyboard. I looked everywhere I could, but no retail keyboard I could find was right for me - either the layout was wrong, or they didn't come in...</p> </div> <div class=\"post-more\"><a class=\"more-link\" href=\"#\">Read more</a></div> </div> </div> <div class=\"col-sm-6 col-md-4 col-lg-4\"> <div class=\"post mb-20\"> <div class=\"post-thumbnail\"><a href=\"#\"><img src=\"assets/images/work-2.jpg\" alt=\"Blog-post Thumbnail\"></a></div> <div class=\"post-header font-alt\"> <h2 class=\"post-title\"><a href=\"#\">How many R-Pis are enough?</a></h2> <div class=\"post-meta\">By&nbsp;<a href=\"#\">Andy River</a>&nbsp;| 11 November | 4 Comments </div> </div> <div class=\"post-entry\"> <p>What do you do when you need a machine that is more powerful than a single R-Pi, but not as powerful as a full PC? You put together as many R-Pis as you want. This is the account of how I built a cluster of...</p> </div> <div class=\"post-more\"><a class=\"more-link\" href=\"#\">Read more</a></div> </div> </div> <div class=\"col-sm-6 col-md-4 col-lg-4\"> <div class=\"post mb-20\"> <div class=\"post-thumbnail\"><a href=\"#\"><img src=\"assets/images/work-3.jpg\" alt=\"Blog-post Thumbnail\"></a></div> <div class=\"post-header font-alt\"> <h2 class=\"post-title\"><a href=\"#\">My door has a fingerprint sensor on it</a></h2> <div class=\"post-meta\">By&nbsp;<a href=\"#\">Dylan Woods</a>&nbsp;| 5 November | 15 Comments </div> </div> <div class=\"post-entry\"> <p>Using fingerprints for authentication in the real world is not only safe, it's also convenient. Imagine a life where you can leave your keys behind and never worry about anything leaving your room.</p> </div> <div class=\"post-more\"><a class=\"more-link\" href=\"#\">Read more</a></div> </div> </div> </div> </div> </section> <!-- <script src=\"assets/lib/jquery/dist/jquery.js\"></script>\n<script src=\"assets/lib/bootstrap/dist/js/bootstrap.min.js\"></script>\n<script src=\"assets/lib/wow/dist/wow.js\"></script>\n<script src=\"assets/lib/jquery.mb.ytplayer/dist/jquery.mb.YTPlayer.js\"></script>\n<script src=\"assets/lib/isotope/dist/isotope.pkgd.js\"></script>\n<script src=\"assets/lib/imagesloaded/imagesloaded.pkgd.js\"></script>\n<script src=\"assets/lib/flexslider/jquery.flexslider.js\"></script>\n<script src=\"assets/lib/owl.carousel/dist/owl.carousel.min.js\"></script>\n<script src=\"assets/lib/smoothscroll.js\"></script>\n<script src=\"assets/lib/magnific-popup/dist/jquery.magnific-popup.js\"></script>\n<script src=\"assets/lib/simple-text-rotator/jquery.simple-text-rotator.min.js\"></script>\n<script src=\"assets/js/plugins.js\"></script> --> <script src=\"assets/js/main.js\"></script>";

      angular.module('angular-templates')
        .run(['$templateCache', function($templateCache) {
          $templateCache.put(templateUrl, template);
        }]);

      module.exports = {};
      module.exports.__esModule = true;
      module.exports.default = templateUrl;
    
//////////////////////////////////////////////////////////////////////////////////////////

}}},"common":{"db.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// common/db.js                                                                         //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
Topics = new Meteor.Collection('Topics');                                               // 1
Threads = new Meteor.Collection('Threads');                                             // 2
Posts = new Meteor.Collection('Posts');                                                 // 3
Blogs = new Meteor.Collection('Blogs');                                                 // 4
//////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"accounts.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// server/accounts.js                                                                   //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
// first, remove configuration entry in case service is already configured              //
ServiceConfiguration.configurations.remove({                                            // 2
  service: "google"                                                                     // 3
});                                                                                     //
ServiceConfiguration.configurations.insert({                                            // 5
  service: "google",                                                                    // 6
  clientId: "592072977958-j96j31mis4tv2061e4n0qcjgsnegpppu.apps.googleusercontent.com",
  secret: "2iKx7tF-SDNL8gFFmG5qUcF5"                                                    // 8
});                                                                                     //
//////////////////////////////////////////////////////////////////////////////////////////

},"defaults.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// server/defaults.js                                                                   //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
if (Topics.find().count() === 0) {                                                      // 1
    _.each([{                                                                           // 2
        name: 'General Discussion',                                                     // 4
        description: 'A place where you can discuss anything and everything'            // 5
    }, {                                                                                //
        name: 'Tutorials',                                                              // 7
        description: 'A place where you can learn stuff'                                // 8
    }, {                                                                                //
        name: 'Help',                                                                   // 10
        description: 'Need something? Ask here.'                                        // 11
    }], function (tempTopic) {                                                          //
        Topics.insert({                                                                 // 14
            name: tempTopic.name,                                                       // 15
            description: tempTopic.description                                          // 16
        });                                                                             //
    });                                                                                 //
}                                                                                       //
                                                                                        //
if (Blogs.find().count() === 0) {                                                       // 21
    _.each([{                                                                           // 22
        name: 'Placeholder 99',                                                         // 24
        author: 'Tom',                                                                  // 25
        content: 'Lorem <h1>ipsum</h1> dolor sit amet, consectetur adipiscing elit. Nullam cursus mi tortor, non dignissim turpis porttitor quis. Fusce lobortis justo vel ligula vehicula suscipit. Nunc semper, dolor ut pulvinar tincidunt, lorem nisi ullamcorper nibh, ac commodo massa nisi vitae ligula. Suspendisse quis tempus nulla. Ut ullamcorper, enim at consequat dictum, augue tellus mollis justo, id dignissim augue libero sit amet dui. Aenean consequat justo lorem, sit amet posuere arcu feugiat ac. Duis tincidunt placerat tortor id posuere. Aenean pulvinar ultricies risus ac suscipit. Suspendisse commodo libero et facilisis maximus.nterdum et malesuada fames ac ante ipsum primis in faucibus. Duis nec suscipit lectus. Interdum et malesuada fames ac ante ipsum primis in faucibus. Donec massa dolor, facilisis nec justo in, aliquet viverra lacus. Sed quis molestie libero. Donec ac leo ac enim vulputate cursus non nec eros. In tempor ex a dui fermentum fringilla.Nullam sit amet neque efficitur dui tincidunt tempor. Phasellus hendrerit tempor turpis, eu rhoncus nisl imperdiet et. Praesent at venenatis neque. Nullam a mauris lorem. Cras pretium massa tellus, sit amet semper metus tempor eu. Ut tincidunt venenatis tincidunt. Nam luctus euismod neque.'
    }, {                                                                                //
        name: 'Placeholder 2',                                                          // 28
        author: 'Dick',                                                                 // 29
        content: 'Lorem <h1>ipsum</h1> dolor sit amet, consectetur adipiscing elit. Nullam cursus mi tortor, non dignissim turpis porttitor quis. Fusce lobortis justo vel ligula vehicula suscipit. Nunc semper, dolor ut pulvinar tincidunt, lorem nisi ullamcorper nibh, ac commodo massa nisi vitae ligula. Suspendisse quis tempus nulla. Ut ullamcorper, enim at consequat dictum, augue tellus mollis justo, id dignissim augue libero sit amet dui. Aenean consequat justo lorem, sit amet posuere arcu feugiat ac. Duis tincidunt placerat tortor id posuere. Aenean pulvinar ultricies risus ac suscipit. Suspendisse commodo libero et facilisis maximus.nterdum et malesuada fames ac ante ipsum primis in faucibus. Duis nec suscipit lectus. Interdum et malesuada fames ac ante ipsum primis in faucibus. Donec massa dolor, facilisis nec justo in, aliquet viverra lacus. Sed quis molestie libero. Donec ac leo ac enim vulputate cursus non nec eros. In tempor ex a dui fermentum fringilla.Nullam sit amet neque efficitur dui tincidunt tempor. Phasellus hendrerit tempor turpis, eu rhoncus nisl imperdiet et. Praesent at venenatis neque. Nullam a mauris lorem. Cras pretium massa tellus, sit amet semper metus tempor eu. Ut tincidunt venenatis tincidunt. Nam luctus euismod neque.'
    }, {                                                                                //
        name: 'Placeholder 3',                                                          // 32
        author: 'Harry',                                                                // 33
        content: 'Lorem <h1>ipsum</h1> dolor sit amet, consectetur adipiscing elit. Nullam cursus mi tortor, non dignissim turpis porttitor quis. Fusce lobortis justo vel ligula vehicula suscipit. Nunc semper, dolor ut pulvinar tincidunt, lorem nisi ullamcorper nibh, ac commodo massa nisi vitae ligula. Suspendisse quis tempus nulla. Ut ullamcorper, enim at consequat dictum, augue tellus mollis justo, id dignissim augue libero sit amet dui. Aenean consequat justo lorem, sit amet posuere arcu feugiat ac. Duis tincidunt placerat tortor id posuere. Aenean pulvinar ultricies risus ac suscipit. Suspendisse commodo libero et facilisis maximus.nterdum et malesuada fames ac ante ipsum primis in faucibus. Duis nec suscipit lectus. Interdum et malesuada fames ac ante ipsum primis in faucibus. Donec massa dolor, facilisis nec justo in, aliquet viverra lacus. Sed quis molestie libero. Donec ac leo ac enim vulputate cursus non nec eros. In tempor ex a dui fermentum fringilla.Nullam sit amet neque efficitur dui tincidunt tempor. Phasellus hendrerit tempor turpis, eu rhoncus nisl imperdiet et. Praesent at venenatis neque. Nullam a mauris lorem. Cras pretium massa tellus, sit amet semper metus tempor eu. Ut tincidunt venenatis tincidunt. Nam luctus euismod neque.'
    }, {                                                                                //
        name: 'Placeholder 4',                                                          // 36
        author: 'Ballsy',                                                               // 37
        content: 'Lorem <h1>ipsum</h1> dolor sit amet, consectetur adipiscing elit. Nullam cursus mi tortor, non dignissim turpis porttitor quis. Fusce lobortis justo vel ligula vehicula suscipit. Nunc semper, dolor ut pulvinar tincidunt, lorem nisi ullamcorper nibh, ac commodo massa nisi vitae ligula. Suspendisse quis tempus nulla. Ut ullamcorper, enim at consequat dictum, augue tellus mollis justo, id dignissim augue libero sit amet dui. Aenean consequat justo lorem, sit amet posuere arcu feugiat ac. Duis tincidunt placerat tortor id posuere. Aenean pulvinar ultricies risus ac suscipit. Suspendisse commodo libero et facilisis maximus.nterdum et malesuada fames ac ante ipsum primis in faucibus. Duis nec suscipit lectus. Interdum et malesuada fames ac ante ipsum primis in faucibus. Donec massa dolor, facilisis nec justo in, aliquet viverra lacus. Sed quis molestie libero. Donec ac leo ac enim vulputate cursus non nec eros. In tempor ex a dui fermentum fringilla.Nullam sit amet neque efficitur dui tincidunt tempor. Phasellus hendrerit tempor turpis, eu rhoncus nisl imperdiet et. Praesent at venenatis neque. Nullam a mauris lorem. Cras pretium massa tellus, sit amet semper metus tempor eu. Ut tincidunt venenatis tincidunt. Nam luctus euismod neque.'
    }, {                                                                                //
        name: 'Placeholder 5',                                                          // 40
        author: 'Blabla',                                                               // 41
        content: 'Lorem <h1>ipsum</h1> dolor sit amet, consectetur adipiscing elit. Nullam cursus mi tortor, non dignissim turpis porttitor quis. Fusce lobortis justo vel ligula vehicula suscipit. Nunc semper, dolor ut pulvinar tincidunt, lorem nisi ullamcorper nibh, ac commodo massa nisi vitae ligula. Suspendisse quis tempus nulla. Ut ullamcorper, enim at consequat dictum, augue tellus mollis justo, id dignissim augue libero sit amet dui. Aenean consequat justo lorem, sit amet posuere arcu feugiat ac. Duis tincidunt placerat tortor id posuere. Aenean pulvinar ultricies risus ac suscipit. Suspendisse commodo libero et facilisis maximus.nterdum et malesuada fames ac ante ipsum primis in faucibus. Duis nec suscipit lectus. Interdum et malesuada fames ac ante ipsum primis in faucibus. Donec massa dolor, facilisis nec justo in, aliquet viverra lacus. Sed quis molestie libero. Donec ac leo ac enim vulputate cursus non nec eros. In tempor ex a dui fermentum fringilla.Nullam sit amet neque efficitur dui tincidunt tempor. Phasellus hendrerit tempor turpis, eu rhoncus nisl imperdiet et. Praesent at venenatis neque. Nullam a mauris lorem. Cras pretium massa tellus, sit amet semper metus tempor eu. Ut tincidunt venenatis tincidunt. Nam luctus euismod neque.'
    }], function (tempBlog) {                                                           //
        Blogs.insert({                                                                  // 45
            name: tempBlog.name,                                                        // 46
            author: tempBlog.author,                                                    // 47
            content: tempBlog.content                                                   // 48
        });                                                                             //
    });                                                                                 //
}                                                                                       //
//////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// server/methods.js                                                                    //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
Meteor.methods({                                                                        // 1
	createThread: function createThread(topicId, title, content) {                         // 2
		check(topicId, String);                                                               // 3
		check(content, String);                                                               // 4
                                                                                        //
		var user = Meteor.user();                                                             // 6
		if (!user) {                                                                          // 7
			throw new Meteor.Error("You need to be logged in to do this!");                      // 8
		}                                                                                     //
		if (!title) {                                                                         // 10
			throw new Meteor.Error("Title can't be empty!");                                     // 11
		}                                                                                     //
		if (!content) {                                                                       // 13
			throw new Meteor.Error("You can't create an empty thread!");                         // 14
		}                                                                                     //
                                                                                        //
		var thread = {                                                                        // 17
			author: user.profile.name,                                                           // 18
			createdAt: new Date(),                                                               // 19
			topicId: topicId,                                                                    // 20
			title: title,                                                                        // 21
			content: content                                                                     // 22
		};                                                                                    //
		return Threads.insert(thread);                                                        // 24
	},                                                                                     //
                                                                                        //
	createPost: function createPost(threadId, content) {                                   // 27
		check(threadId, String);                                                              // 28
		check(content, String);                                                               // 29
                                                                                        //
		var user = Meteor.user();                                                             // 31
                                                                                        //
		if (!user) {                                                                          // 33
			throw new Meteor.Error("You need to be logged in to do this!");                      // 34
		}                                                                                     //
		if (!content) {                                                                       // 36
			throw new Meteor.Error("Post can't be empty");                                       // 37
		}                                                                                     //
                                                                                        //
		var post = {                                                                          // 40
			author: user.emails[0].address,                                                      // 41
			createdAt: new Date(),                                                               // 42
			threadId: threadId,                                                                  // 43
			content: content                                                                     // 44
		};                                                                                    //
		return Posts.insert(post);                                                            // 46
	}                                                                                      //
});                                                                                     //
//////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// server/publications.js                                                               //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
Meteor.publish('topics', function () {                                                  // 1
	return Topics.find();                                                                  // 2
});                                                                                     //
                                                                                        //
Meteor.publish('topic', function (id) {                                                 // 5
	check(id, String);                                                                     // 6
	return Topics.find({ _id: id });                                                       // 7
});                                                                                     //
                                                                                        //
Meteor.publish('threads', function (topicId) {                                          // 10
	check(topicId, String);                                                                // 11
	return Threads.find({ topicId: topicId });                                             // 12
});                                                                                     //
                                                                                        //
Meteor.publish('thread', function (id) {                                                // 15
	check(id, String);                                                                     // 16
	return Threads.find({ _id: id });                                                      // 17
});                                                                                     //
                                                                                        //
Meteor.publish('posts', function (threadId) {                                           // 20
	check(threadId, String);                                                               // 21
	return Posts.find({ threadId: threadId });                                             // 22
});                                                                                     //
                                                                                        //
Meteor.publish('post', function (id) {                                                  // 25
	check(id, String);                                                                     // 26
	return Posts.find({ _id: id });                                                        // 27
});                                                                                     //
                                                                                        //
Meteor.publish('blogs', function () {                                                   // 30
	return Blogs.find();                                                                   // 31
});                                                                                     //
                                                                                        //
Meteor.publish('blog', function (id) {                                                  // 34
	check(id, String);                                                                     // 35
	return Blogs.find({ _id: id });                                                        // 36
});                                                                                     //
//////////////////////////////////////////////////////////////////////////////////////////

},"main.js":["meteor/meteor","meteor/accounts-base",function(require){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// server/main.js                                                                       //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
var _meteorMeteor = require('meteor/meteor');                                           //
                                                                                        //
var _meteorAccountsBase = require('meteor/accounts-base');                              //
                                                                                        //
_meteorMeteor.Meteor.startup(function () {                                              // 3
  // code to run on server at startup                                                   //
});                                                                                     //
//////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".html"]});
require("./views/pages/blog.html");
require("./views/pages/blogs.html");
require("./views/pages/thread.html");
require("./views/pages/topic.html");
require("./views/pages/topics.html");
require("./views/pages/welcome.html");
require("./common/db.js");
require("./server/accounts.js");
require("./server/defaults.js");
require("./server/methods.js");
require("./server/publications.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
